import os
from dataclasses import dataclass


def _float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    bot_display_name: str = os.getenv("BOT_DISPLAY_NAME", "Degen Detector")
    bot_tagline: str = os.getenv("BOT_TAGLINE", "Detect the send before the trend.")
    database_path: str = os.getenv("DATABASE_PATH", "commander_bot.db")
    min_liquidity_usd: float = _float("MIN_LIQUIDITY_USD", 25_000)
    max_top10_holder_pct: float = _float("MAX_TOP10_HOLDER_PCT", 35)
    max_slippage_pct: float = _float("MAX_SLIPPAGE_PCT", 3)
    approval_score: float = _float("COMMANDER_APPROVAL_SCORE", 72)
    paper_position_usd: float = _float("PAPER_POSITION_USD", 25)
    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    telegram_owner_id: str = os.getenv("TELEGRAM_OWNER_ID", os.getenv("TELEGRAM_CHAT_ID", ""))
    telegram_tester_ids: str = os.getenv("TELEGRAM_TESTER_IDS", "")
    telegram_alert_group_id: str = os.getenv("TELEGRAM_ALERT_GROUP_ID", "")
    telegram_poll_seconds: int = _int("TELEGRAM_POLL_SECONDS", 20)
    manual_session_minutes: int = _int("MANUAL_SESSION_MINUTES", 60)
    helius_api_key: str = os.getenv("HELIUS_API_KEY", "")
    live_data_enabled: bool = _bool("LIVE_DATA_ENABLED", False)
    live_candidate_limit: int = _int("LIVE_CANDIDATE_LIMIT", 20)
    scan_result_limit: int = _int("SCAN_RESULT_LIMIT", 10)
    scan_qualified_score: float = _float("SCAN_QUALIFIED_SCORE", 75)
    tester_scan_cooldown_seconds: int = _int("TESTER_SCAN_COOLDOWN_SECONDS", 90)
    practice_starting_balance_usd: float = _float("PRACTICE_STARTING_BALANCE_USD", 10_000)
    practice_hourly_buy_limit_usd: float = _float("PRACTICE_HOURLY_BUY_LIMIT_USD", 2_000)
    practice_fee_pct: float = _float("PRACTICE_FEE_PCT", 0.50)
    practice_slippage_pct: float = _float("PRACTICE_SLIPPAGE_PCT", 1.00)
    auto_scan_interval_minutes: int = _int("AUTO_SCAN_INTERVAL_MINUTES", 15)
    auto_alert_min_score: float = _float("AUTO_ALERT_MIN_SCORE", 60)
    auto_duplicate_cooldown_minutes: int = _int("AUTO_DUPLICATE_COOLDOWN_MINUTES", 180)
    auto_timezone: str = os.getenv("AUTO_TIMEZONE", "Australia/Brisbane")
    auto_peak_start_hour: int = _int("AUTO_PEAK_START_HOUR", 18)
    auto_peak_end_hour: int = _int("AUTO_PEAK_END_HOUR", 2)
    wallet_check_interval_seconds: int = _int("WALLET_CHECK_INTERVAL_SECONDS", 60)
    paper_copy_max_open_positions: int = _int("PAPER_COPY_MAX_OPEN_POSITIONS", 10)
    launchpad_min_score: float = _float("LAUNCHPAD_MIN_SCORE", 75)
    launchpad_candidate_limit: int = _int("LAUNCHPAD_CANDIDATE_LIMIT", 20)
    master_entry_score: float = _float("MASTER_ENTRY_SCORE", 80)
    master_min_data_confidence: float = _float("MASTER_MIN_DATA_CONFIDENCE", 60)
    master_stop_loss_pct: float = _float("MASTER_STOP_LOSS_PCT", 12)
    master_take_profit_1_pct: float = _float("MASTER_TAKE_PROFIT_1_PCT", 25)
    master_take_profit_2_pct: float = _float("MASTER_TAKE_PROFIT_2_PCT", 60)
    master_trailing_stop_pct: float = _float("MASTER_TRAILING_STOP_PCT", 15)
    master_max_positions: int = _int("MASTER_MAX_POSITIONS", 5)
    master_daily_loss_limit_usd: float = _float("MASTER_DAILY_LOSS_LIMIT_USD", 100)
    x_bearer_token: str = os.getenv("X_BEARER_TOKEN", "")
    youtube_api_key: str = os.getenv("YOUTUBE_API_KEY", "")
    tiktok_access_token: str = os.getenv("TIKTOK_ACCESS_TOKEN", "")
    instagram_access_token: str = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")
    facebook_access_token: str = os.getenv("FACEBOOK_ACCESS_TOKEN", "")
    reddit_access_token: str = os.getenv("REDDIT_ACCESS_TOKEN", "")
